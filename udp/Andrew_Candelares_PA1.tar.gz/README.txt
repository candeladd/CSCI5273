CSCI 4273 Network Systems
Fall 2016

Created by: Andrew Candelaresi

Built a UDP datagram socket capable of sending and revieving files reliably.

Build server & client
	make

Run Server
	./server <port number> //You should select port #'s > 5000.

Run Client
	./client <server IP address> <server port number>

